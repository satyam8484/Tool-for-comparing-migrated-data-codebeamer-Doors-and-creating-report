# import load_workbook
from openpyxl import load_workbook
import webbrowser
import configparser
import os
import logging
logging.basicConfig(filename='myapp.log', level=logging.INFO)
logging.info('Started')


parser = configparser.ConfigParser()
parser.read('config.ini')

def Doors_Excel(doors_file_path):
    #===============================================================================
    # Read Doors excel File
    #===============================================================================

    print(doors_file_path)
    # set file path
    doors_filepath=doors_file_path
    # load demo.xlsx
    wb=load_workbook(doors_filepath)
    # select demo.xlsx
    sheet=wb.active
    # get max row count
    max_row=sheet.max_row
    # get max column count
    max_column=sheet.max_column

    doors_dict = dict()
    doors_dict_order_check = dict()

    type_dict = parser._sections['type_val_dict']



    foreign_id = sheet.cell(row=1, column=1).value
    doors_name = sheet.cell(row=1, column=3).value
    status = sheet.cell(row=1, column=4).value
    type_val = sheet.cell(row=1, column=5).value
    type_val_1 = ""
    col_heading = [foreign_id,doors_name,status, type_val]
    #print(type_dict)


    # iterate over all cells
    # iterate over all rows
    for i in range(2,max_row+1):
        foreign_id=int(sheet.cell(row=i,column=1).value.split('-')[-1])
        doors_name =sheet.cell(row=i,column=3).value
        status =sheet.cell(row=i,column=4).value
        type_val =sheet.cell(row=i,column=5).value
        #print(type_val)


        if(status != None):
            status = status.strip().lower()
        if(type_val != None):
            if(type_val.lower() in type_dict):
                type_val_1 = type_dict[type_val.lower()].strip()
                #print(type_val," TT ",type_val_1)
            #type_val = type_val.replace("-","").replace('Requirement','')
            #type_val = type_val.strip().lower()


        doors_dict[foreign_id] = [status,type_val,foreign_id,doors_name,type_val_1]
        doors_dict_order_check[i] = [foreign_id,doors_name,status,type_val]

        #----------------------------------------- print(foreign_id,status,type_val)

    return [doors_dict,doors_dict_order_check,col_heading]

def get_cb_dict(cb_file_path):

    global parser

    # set file path
    cb_filepath=cb_file_path

    # load demo.xlsx
    wb=load_workbook(cb_filepath)
    # select demo.xlsx
    sheet=wb.active
    # get max row count
    max_row=sheet.max_row
    # get max column count
    max_column=sheet.max_column

    cb_dict = dict()
    cb_dict_as_for_key = dict()

    cb_id = sheet.cell(row=1, column=1).value
    cb_foreign_id = sheet.cell(row=1, column=2).value
    cb_Name = sheet.cell(row=1, column=3).value
    cb_status = sheet.cell(row=1, column=4).value
    cb_type_val = sheet.cell(row=1, column=5).value

    cb_col_heading = [cb_id,cb_foreign_id,cb_Name,cb_status,cb_type_val]

    for i in range(2,max_row+1):
        cb_id = sheet.cell(row=i,column=1).value
        cb_foreign_id=int(sheet.cell(row=i,column=2).value)
        cb_Name=sheet.cell(row=i,column=3).value
        cb_status =sheet.cell(row=i,column=4).value
        cb_type_val =sheet.cell(row=i,column=5).value

        cb_dict[i] = [cb_id,cb_foreign_id,cb_Name,cb_status,cb_type_val]
        cb_dict_as_for_key[cb_foreign_id] = [cb_id,cb_foreign_id,cb_Name,cb_status,cb_type_val]

    return [cb_dict,cb_col_heading,cb_dict_as_for_key]

def display_unorder_items(fw,doors_val_list,cb_val_list):

    doors_val_list = doors_val_list
    doors_dict_order_check = doors_val_list[1]
    cb_val_list = cb_val_list
    cb_dict = cb_val_list[0]
    cb_dict_as_for_key = cb_val_list[2]
    doors_dict = doors_val_list[0]
    doors_col_heading = doors_val_list[2]

    #===========================================================================
    # Items with Mismatch DOORs ID (Foreign ID):
    #===========================================================================
    flag = True
    print("<a id='mismatchitems'></a>",file=fw)
    print("<table id='cb'>", file=fw)
    print("<caption id='mismatch_door_cb'> Items with Mismatch DOORs ID (Foreign ID): </caption>", file=fw)

    #logging.info(doors_dict)
    #logging.info(cb_dict_as_for_key)

    mismatch_door_cb_cnt = 0
    for k,v in doors_dict.items():

        if k not in cb_dict_as_for_key:
            if(flag):
                print("<tr>", file=fw)
                for door_head in doors_col_heading:
                    print("<th>" + str(door_head) + "</th>", file=fw)
                print("</tr>", file=fw)

            print("<tr>",file=fw)
            for i in [2,3,0,1]:
                print("<td>"+str(v[i])+"</td>",file=fw)
            print("</tr>",file=fw)
            flag = False
            mismatch_door_cb_cnt+=1

    js = """
    <script>
    var html_content = document.getElementById("mismatch_door_cb").textContent
    html_content=html_content + '\t <i style=color:red;>count of items ' + """+str(mismatch_door_cb_cnt)+"""+'</i>'
    document.getElementById("mismatch_door_cb").innerHTML = html_content
    </script>
    """
    print(js,file=fw)

    if(flag):
        print("<tr><td>No Items Found</td></tr>", file=fw)
    print("</table>", file=fw)


    #===========================================================================
    # Items with Un-ordered items (Door's List)
    #===========================================================================

    print("<a id='unorderitems'></a>",file=fw)
    print("<table id='cb'>", file=fw)
    print("<caption id='unorder_items'> Items with Un-ordered items (Door's List)</caption>", file=fw)
    flag = True
    un_order_cnt = 0
    for k,v in doors_dict_order_check.items():
        doors_values = []
        try:
            if(v[0] != cb_dict[k][1]):
                doors_values = v
                # print(v)
        except:
            doors_values = v
            # print(v)

        if(len(doors_values)!=0):
            if(flag):
                print("<tr>", file=fw)
                for door_head in doors_col_heading:
                    print("<th>" + str(door_head) + "</th>", file=fw)
                print("</tr>", file=fw)

            print("<tr>",file=fw)
            for val in doors_values:
                print("<td>"+str(val)+"</td>",file=fw)
            print("</tr>",file=fw)
            flag = False
            un_order_cnt+=1

    if(flag):
        print("<tr><td>No Items Found</td></tr>", file=fw)

    js = """
    <script>
    var html_content = document.getElementById("unorder_items").textContent
    html_content=html_content + '\t <i style=color:yellow;>count of items ' + """+str(un_order_cnt)+"""+'</i>'
    document.getElementById("unorder_items").innerHTML = html_content
    </script>
    """
    print(js,file=fw)

    print("</table>",file=fw)

def create_tracker_link(cb_dict):
    cb_id = cb_dict[2][0]
    link = 'http://bee.brose.net/cb/issue/'+str(cb_id)
    return link

def CB_Excel(doors_file_path,cb_file_path,CB_Project_Name,cb_tracker_name):
    #===============================================================================
    # Comapre Doors with Codebeamer (Status & Type)
    # Read Codebeamer excel File
    #===============================================================================

    global parser
    doors_val_list = Doors_Excel(doors_file_path)
    doors_dict = doors_val_list[0]
    doors_col_heading = doors_val_list[2]
    cb_val_list = get_cb_dict(cb_file_path)
    cb_dict= cb_val_list[0]
    cb_col_heading = cb_val_list[1]

    # set file path
    cb_filepath=cb_file_path

    # Writting data to html file
    cb_file_name = cb_filepath.split("\\")[-1]
    dir_path = cb_filepath.strip(cb_file_name)
    cb_file_name = cb_file_name.replace(".xlsx","")
    cb_file_name = cb_file_name +"_Report.html"

    cb_html_file_path = dir_path+"\\"+cb_file_name
    #logging.info(cb_html_file_path)
    fw = open(cb_html_file_path,'w')
    html_syntax = """<html>
    <head>
    <script src="https://kit.fontawesome.com/a076d05399.js"></script>
    <style>
    #cb {
      font-family: Arial, Helvetica, sans-serif;
      border-collapse: collapse;
      width: 70%;
      margin-bottom:20px;
      margin-left: auto;
      margin-right: auto;
    }

    #cb td, #cb th {
      border: 1px solid #ddd;
      padding: 8px;
    }

    #cb tr:nth-child(even){background-color: #f2f2f2;}

    #cb tr:hover {background-color: #ddd;}

    #cb th {
      padding-top: 12px;
      padding-bottom: 12px;
      text-align: left;
      background-color: #4C4B4B;
      color: white;
    }

    caption {
      padding-top: 12px;
      padding-bottom: 12px;
      text-align: center;
      background-color: #4C4B4B;
      color: white;
      font-weight: bold;
    }

    #box{
      width: 380px;
      border: 5px solid #4C4B4B;
      padding: 25px;
      margin-left: auto;
      margin-right: auto;
      margin-bottom: 50px;
      background-color: #f2f2f2;
      color:green;
      font-size:18px;
      font-family: Verdana;
    }
    #toc_container {
    background: #f9f9f9 none repeat scroll 0 0;
    border: 1px solid #aaa;
    display: table;
    font-size: 150%;
    margin-bottom: 1em;
    padding: 20px;
    width: auto;
    margin-left: auto;
    margin-right: auto;
    text-decoration:none;

    }

    .toc_title {
        font-weight: 700;
        text-align: center;
    }


    #toc_container a{
        text-decoration:none;
    }

    </style>
    </head>
    <body>"""
    fw.write(html_syntax)
    cb_file_name_heading=cb_file_name.replace("_Report.html","").replace('Tracker_view_','')
    message = "<center><h1 style=color:#1133ff; margin:20px 0px 10px;>Migration Comparision Report - "+cb_file_name_heading+"</h1></center>"
    fw.write(message)
    link = """
    <div id="toc_container">
    <p class="toc_title">Information</p>
    <table id='cb'>
    <tr><th>Project Name</th><td >"""+CB_Project_Name+""" </td><td id='Tracker_link'><i class="fa fa-eye" aria-hidden="true"></i></td></tr>
    <tr><th>Tracker Name</th><td>"""+cb_tracker_name+"""</td><td></td></tr>
    </table>
    <br>
    <p class="toc_title">Contents</p>
    <ol class='toc_list'>
    <li><a href=#mismatchitems>Items with Mismatch DOORs ID (Foreign ID)</a> </li>
    <li><a href=#unorderitems>Items with Un-ordered items (Door's List)</a> </li>
    <li><a href=#diffinstatus>Difference in Status</a> </li>
    <li><a href=#diffintype>Difference in Type</a></li>
    </ol>
    <br>
    </div>
    """
    print(link,file=fw)

    display_unorder_items(fw,doors_val_list,cb_val_list)

    cnt = 0
    doors_status_list= []
    cb_status_list = []

    type_dict = parser._sections['type_val_dict']

    status_list = ['accepted','to clarify','rejected']
    type_list = list(type_dict.values())

    diff_status_dict = dict()
    for st in status_list:
        diff_status_dict[st] = []

    diff_type_dict = dict()
    for ty in type_list:
        diff_type_dict[ty] = []

    #logging.info(diff_status_dict)
    #logging.info(status_list)
    #logging.info(diff_type_dict)
    #logging.info(type_list)

    create_link = create_tracker_link(cb_dict)

    #logging.info(create_link)
    js="""
    <script>
    var cont = document.getElementById('Tracker_link').innerHTML
    var cn = cont.link('"""+create_link+"""')
    document.getElementById('Tracker_link').innerHTML =cn
    </script>
    """

    print(js,file=fw)


    # iterate over all cells
    # iterate over all rows
    for k,v in cb_dict.items():
        cb_id = v[0]
        cb_foreign_id=v[1]
        cb_Name=v[2]
        cb_status =v[3]
        cb_type_val = v[4]
        # if(cb_type_val.strip() == "Headline"):
        #     cb_status = None



        if(cb_status != None):
            cb_status = cb_status.strip().lower()
        #=======================================================================
        # if(cb_type_val != None):
        #     cb_type_val = cb_type_val.replace("-","")
        #     cb_type_val = cb_type_val.strip().lower()
        #=======================================================================

        status_flag = False
        type_flag = False


        if(cb_foreign_id in doors_dict):
            door_val_list = doors_dict[cb_foreign_id]
            #------------------------------ print(door_val_list[0],door_val_list[1])
            #------------------------------------------ print(cb_status,cb_type_val)
            cb_status_list.append(cb_status)
            doors_status_list.append(door_val_list[0])
            if(cb_status == door_val_list[0]):
                status_flag = True

            else:
                status_flag = False
                for st in status_list:
                    if(cb_status== st):
                        diff_status_dict[st].append([cb_id,cb_foreign_id,cb_Name,cb_status,cb_type_val])

            #logging.info(doors_file_path)
            #logging.info(door_val_list[4])
            if(cb_type_val == door_val_list[4]):
                type_flag = True
            else:
                type_flag = False
                for ty in type_list:
                    if(cb_type_val == ty):
                        diff_type_dict[ty].append([cb_id,cb_foreign_id,cb_Name,cb_status,cb_type_val])



        if(status_flag == False or type_flag == False):
            # print(cb_foreign_id)
            # print(cb_foreign_id,status_flag,type_flag,end='<br>',file=fw)
            cnt+=1

    print("<hr>",file=fw)
    print("<a id='diffinstatus'></a>",file=fw)
    print("<h1 style='color:#02079e'><center> ----------  Difference in Status  ---------- </center></h1>",end='<br><br>',file=fw)
    print(f"<h4 id=box>DOORs Attribute name - "+doors_col_heading[2]+"<br>Codebeamer Field Name - "+cb_col_heading[3]+" <br></h4>",file=fw)
    for st in status_list:

#         if(cb_status_list.count(st) == doors_status_list.count(st)):
#             print(f"<h4>number of items with {st} status are same</h4>",end='',file=fw)
#
#         else:
#             print(f"<h4>number of items with {st} status are NOT same</h4>",end='',file=fw)

        print("<table id='cb'>",file=fw)
        print(f"<caption>{st}<caption>",file=fw)

        if (len(diff_status_dict[st]) == 0):
            print("<tr><td>" + "No Difference Found" + "</td></tr>", file=fw)
        else:
            print("<tr>", file=fw)
            for col_head in cb_col_heading:
                print("<th>" + str(col_head) + "<th>", end=' ', file=fw)
            print("</tr>", file=fw)

            for data_list in diff_status_dict[st]:
                print("<tr>",file=fw)
                item_index = 0
                for item in data_list:
                    if(item_index == 0):
                        link = "<a href='http://bee.brose.net/cb/issue/"+str(item)+"' target='_blank'>"+str(item)+"</a>"
                        print("<td>"+link+"<td>",end=' ',file=fw)
                        item_index+=1
                    else:
                        print("<td>"+str(item)+"<td>",end=' ',file=fw)

                print("</tr>",file=fw)

        print("</table>",file=fw)

    print("<hr>", file=fw)
    print("<a id='diffintype'></a>",file=fw)
    print("<h1 style='color:#02079e'><center> ----------  Difference in Type  ---------- </center></h1>",end='<br><br>',file=fw)
    print(f"<h4 id=box>DOORs Attribute name - " + doors_col_heading[3] + "<br>Codebeamer Field Name - " + cb_col_heading[
        4] + " <br></h4>", file=fw)
    for ty in type_list:

#         if(cb_status_list.count(st) == doors_status_list.count(st)):
#             print(f"<h4>number of items with {st} status are same</h4>",end='',file=fw)
#
#         else:
#             print(f"<h4>number of items with {st} status are NOT same</h4>",end='',file=fw)
        print("<table id='cb'>",file=fw)
        print(f"<caption>{ty}<caption>",file=fw)

        if(len(diff_type_dict[ty]) == 0):
            print("<tr><td>"+"No Difference Found"+"</td></tr>",file=fw)
        else:
            print("<tr>", file=fw)
            for col_head in cb_col_heading:
                print("<th>" + str(col_head) + "<th>", end=' ', file=fw)
            print("</tr>", file=fw)

            for data_list in diff_type_dict[ty]:
                print("<tr>",file=fw)
                item_index = 0
                for item in data_list:
                    if(item_index == 0):
                        link = "<a href='http://bee.brose.net/cb/issue/"+str(item)+"' target='_blank'>"+str(item)+"</a>"
                        print("<td>"+link+"<td>",end=' ',file=fw)
                        item_index+=1
                    else:
                        print("<td>"+str(item)+"<td>",end=' ',file=fw)
                print("</tr>",file=fw)

        print("</table>",file=fw)

    # print("<h4> Total No of Difference is "+str(cnt)+"</h4>",end='<br>',file=fw)

    html_syntax = "</body></html>"
    fw.write(html_syntax)
    fw.close()
    webbrowser.open(cb_file_name)

def get_cb_doors_file_path(fol_path_for_CB_Door_comparison):
    global parser

    Project_Fol_Path = fol_path_for_CB_Door_comparison
    #logging.info(Project_Fol_Path)
    # Project_Fol_Path = parser.get('file_path','project_fol_path')
    #Project_Fol_Path = fol_path_for_CB_Door_comparison
    Codebeamer_Tracker_Report_path =Project_Fol_Path+"\Codebeamer Tracker Report"
    DOORs_Module_Report_path=Project_Fol_Path+"\DOORs Module Report"

    CB_Project_Name = Codebeamer_Tracker_Report_path.split("\\")[-2]

    cb_dir_list = os.listdir(Codebeamer_Tracker_Report_path)
    doors_dir_list = os.listdir(DOORs_Module_Report_path)

    doors_file_dict = dict()
    for doors_file in doors_dir_list:
            if(doors_file.endswith(".xlsx")):
                doors_file_short_name = doors_file.lstrip("Module_view_").rstrip(".xls").lstrip('0123456789_').strip()
                doors_file_path = DOORs_Module_Report_path+"\\"+doors_file
                doors_file_dict[doors_file_short_name] = doors_file_path


    for cb_file in cb_dir_list:

        cb_tracker_name = cb_file.lstrip("Tracker_view_").rstrip(".xlsx")
        cb_file_path = Codebeamer_Tracker_Report_path+"\\"+cb_file
        cb_file_short_name = cb_file.lstrip("Tracker_view_").rstrip(".xlsx").lstrip('0123456789_').strip()
        #logging.info(cb_file_short_name)

        if(cb_file_short_name in doors_file_dict):
            doors_file_path = doors_file_dict[cb_file_short_name]
            #logging.info(doors_file_path)
            #logging.info(cb_file_path)
            CB_Excel(doors_file_path,cb_file_path,CB_Project_Name,cb_tracker_name)


if __name__ == "__main__":
    fol_path_for_CB_Door_comparison = parser.get('file_path','project_fol_path')
    get_cb_doors_file_path(fol_path_for_CB_Door_comparison)
    #logging.info("################## "+"Completed"+" ################## ")