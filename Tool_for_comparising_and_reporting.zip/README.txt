
Note : Please Put All Scripts In One Folder for Simplicity

Step 1 :- Open config.ini file and give the parameters 

1. In [Tracker_view_Configuration] Section
 Give UN and Password 
vaiable name = user_name & password 

2.In [file_path] Section
	a] Give the path of xlsx file which contain Projects ID ( Project_id.xlsx )
	variable name = filepath

	b] Give the Path of the Folder Where your All Project Folder Will be Created 
	variable name = project_fol_path 

	c] Give the Path of Doors file where you will get Project List from Doors
	variable name = doors_project_list_file_path


Step 2 :-  Create a Folder Structure for Doors using
	python Create_a_Folder_Structure_for_Doors.py
    Then
    Get a Project ID,Name list from CB using
	python Get_project_id_for_cb.py
	( Will Give You Project_id.xlsx in working Directory)

Step 3 :- First Convert All .xls file to .xlsx using Python Script
	python Convert_xls_to_xlsx.py


####################################################################



Step 4 :- Then run the python programm 

   python Tracker_view_creation_tool_2.py

	In Each Project ("project_fol_path") there is "Codebeamer Tracker Report" Folder where you will get "Report" in Html Format







