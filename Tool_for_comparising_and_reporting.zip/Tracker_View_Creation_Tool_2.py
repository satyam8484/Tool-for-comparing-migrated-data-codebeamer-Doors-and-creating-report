import json
import requests
from requests.auth import HTTPBasicAuth
from openpyxl import Workbook
import os
from openpyxl import load_workbook
import configparser
from COMPARE_TYPE_STATUS_MODIFY import get_cb_doors_file_path

parser = configparser.SafeConfigParser()
parser.read('config.ini')
usr_name = parser.get('Tracker_view_Configuration', 'user_name')
pwd = parser.get('Tracker_view_Configuration', 'password')
filepath = parser.get('file_path', 'filepath')
fol_path = parser.get('file_path','project_fol_path')
fol_path_for_CB_Door_comparison=""

row_i = 1
book = None
sheet = None

def create_workbook():
    global row_i,book,sheet
    book = Workbook()
    sheet = book.active

    row_i = 1
    col_j = 1
    name_list = [ 'ID', 'Foreign ID', 'Name', 'status','Type']
    for item in name_list:
        sheet.cell(row=row_i, column=col_j).value = item
        col_j+=1
    row_i+=1

def get_tracker_item_info(items_URL):

    #===========================================================================
    # used for fetching basic information of a tracker item
    #===========================================================================

    global row_i,usr_name,pwd,sheet
    excel_list = []
    response = requests.get(items_URL,auth = (usr_name,pwd))

    try:
        json_data = response.json()
        item_dict = json_data
    except Exception as e:
        print(e)
        return

    try:
        pass
        # print(item_dict)
        # print(item_dict.keys())
    except:
        pass

    try:
        item_id = item_dict['id']
    except:
        item_id = ""

    try:
        item_ForeignID = ""
        for i in item_dict['customFields']:
            if(i['name'].strip() == "ForeignID"):
                item_ForeignID = i['value']
                break
    except:
        item_ForeignID = ""

    try:
        item_name = item_dict['name']
    except:
        item_name = ""

    try:
        item_status = item_dict['status']['name']
    except:
        item_status = ""

    try:
        item_type = (item_dict['categories'][0])['name']
    except:
        item_type = ""

    #####         WE CAN GET THE INFORMATION OF FOLLOWING FIELDS           #####
    #------------------------   print(item_dict.keys)  ------------------------#
    #===========================================================================
    # for i in item_dict['customFields']:
    #     print(i['name'])
    #===========================================================================

    excel_list = [item_id,item_ForeignID,item_name,item_status,item_type]

    col_j = 1
    for item in excel_list:
        try:
            sheet.cell(row=row_i, column=col_j).value = str(item).encode("ascii",errors="ignore")
        except:
            pass
        #print(col_j)
        col_j+=1
    row_i+=1


#===============================================================================
# def get_items_specific_tracker(tracker_id,tracker_name):
#
#     #===========================================================================
#     # # Get items in a specific tracker
#     #===========================================================================
#     global book,fol_path
#     create_workbook()
#
#     # tracker_id = 359024
#     URL = "https://bee.brose.net/cb/api/v3/trackers/"+str(tracker_id)+"/items?page=1&pageSize=500"
#
#     response = requests.get(URL,auth=HTTPBasicAuth(usr_name,pwd))
#
#     # second way to load JSON Data
#     json_dict = response.json()
#
#     #===========================================================================
#     # print(json_dict.keys())
#     # print(json_dict['itemRefs'])
#     #===========================================================================
#
#     tracker_item = json_dict['itemRefs']
#
#     for d in tracker_item:
#         # print(d['id'])
#         items_URL = "https://bee.brose.net/cb/api/v3/items/"+str(d['id'])
#         get_tracker_item_info(items_URL)
#
#         #--------------------------------------------------------------------- break
#
#
#
#     if(json_dict['total']>0):
#         excel_file_path = fol_path+"/"+"Tracker_view_"+str(tracker_name)+".xlsx"
#         book.save(excel_file_path)
#===============================================================================
def get_list_of_items_in_tracker(tracker_id):

    #===========================================================================
    # Get outline of a specific tracker
    #===========================================================================
    tracker_items_id_list = []
    global usr_name,pwd
    URL = "http://bee.brose.net/cb/rest/tracker/"+str(tracker_id)+"/outline/?paragraph=true"
    response = requests.get(URL,auth=HTTPBasicAuth(usr_name,pwd))
    outline_json = response.json()

    def childern_item(child_dict):
        for child1 in child_dict:
            # print(child1['id'])
            id = child1['id']
            tracker_items_id_list.append(id)
            try:
                if(len(child1['children'])>0):
                    childern_item(child1['children'])
            except:
                pass

    for sub_fol_dict in outline_json:
        # print(sub_fol_dict['id'])
        id = sub_fol_dict['id']
        tracker_items_id_list.append(id)
        try:
            childern_item(sub_fol_dict['children'])
        except:
            pass
        #=======================================================================
        # for child1 in sub_fol_dict['children']:
        #     print(child1)
        #=======================================================================
    return(tracker_items_id_list)

def get_list_of_items_of_specific_tracker(tracker_id,tracker_name):
    #===========================================================================
    # Get outline of a specific tracker
    # Get List of Items in specific Tracker
    #===========================================================================

    global book,fol_path,usr_name,pwd
    create_workbook()

    tracker_item_id_list = get_list_of_items_in_tracker(tracker_id)

    for item_id in tracker_item_id_list:
        print("Item ID ",item_id,end='')
        items_URL = "https://bee.brose.net/cb/api/v3/items/"+str(item_id)
        get_tracker_item_info(items_URL)

    if(len(tracker_item_id_list)>0):
        excel_file_path = fol_path+"\\"+"Tracker_view_"+str(tracker_name)+".xlsx"
        book.save(excel_file_path)


#get_items_specific_tracker(359024)


def get_trakers_of_project(project_id_list):

    #===========================================================================
    # get all Trackers of that Project
    #===========================================================================

    #project_id_list = [63]

    for project_id in project_id_list:

        global fol_path,fol_path_for_CB_Door_comparison
        URL = "https://bee.brose.net/cb/api/v3/projects/"+str(project_id)+"/trackers"

        response = requests.get(URL,auth=HTTPBasicAuth(usr_name,pwd))

        try:
            json_tracker = response.json()
        except:
            return

        URL = "http://bee.brose.net/cb/api/v3/projects/"+str(project_id)
        response = requests.get(URL,auth=HTTPBasicAuth(usr_name,pwd))
        Project_info = response.json()
        project_name = Project_info['name']

        fol_path = parser.get('file_path','project_fol_path')
        fol_path_for_CB_Door_comparison = fol_path+"\\"+project_name

        fol_path = fol_path+"\\"+project_name+"\\"+"Codebeamer Tracker Report"
        print(fol_path)

        if(not(os.path.isdir(fol_path_for_CB_Door_comparison))):
            try:
                os.mkdir(fol_path_for_CB_Door_comparison)
                os.mkdir(fol_path)
            except:
                pass

#         if(len(json_tracker) > 0):
#             fol_path=fol_path+"\\Project_ID_"+str(project_id)+"_"+project_name
#             os.mkdir(path = fol_path)
#             print(fol_path)

        try:
            print("Project ID ",project_id)
        except:
            pass

        for json_dict in json_tracker:
            tracker_id = json_dict['id']
            tracker_name = json_dict['name']
            try:
                print("Tracker ID ",tracker_id,tracker_name)
            except:
                pass

            get_list_of_items_of_specific_tracker(tracker_id,tracker_name)

        try:
            get_cb_doors_file_path(fol_path_for_CB_Door_comparison)
        except:
            print("Error In Comparision in CB & Doors")
        # break

def get_project_ids_from_file():

    #===========================================================================
    # Read Excel file which Contain List of
    # Projects ID's
    #===========================================================================

    global filepath
    # filepath = r"\\brose.net\users\PUN\homep\pawarsa\UserDir\Desktop\project_id.xlsx"
    # load demo.xlsx
    wb=load_workbook(filepath)
    # select demo.xlsx
    sheet=wb.active
    # get max row count
    max_row=sheet.max_row
    # get max column count
    max_column=sheet.max_column

    project_id_list = []
    # iterate over all cells
    # iterate over all rows
    for i in range(2,max_row+1):
        cell_obj=sheet.cell(row=i,column=1)
        project_id_list.append(cell_obj.value)

    #project_id_list = [63]
    get_trakers_of_project(project_id_list)

if __name__ == "__main__":
    get_project_ids_from_file()
    print("----------- Completed -----------")