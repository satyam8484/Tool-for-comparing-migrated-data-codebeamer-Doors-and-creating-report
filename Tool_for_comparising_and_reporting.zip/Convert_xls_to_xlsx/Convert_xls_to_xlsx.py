# -*- coding: utf-8 -*-
"""
Created on Tue Dec 15 11:16:26 2020

@author: pawarsa
"""



import pandas as pd
import os

def convert_xlx_to_xlsx(file_path,out_path):
    data = pd.read_html(file_path)
    print(len(data))
    data[0].to_excel(out_path,index=False,header=False)


DOORs_Module_Report_path=r"\\brose.net\bfr$\func\ZEL\DOORs_Archive-Files\DOORs-Migration\Archive-Project-module-report\P_maserati_hfa\DOORs Module Report"
doors_dir_list = os.listdir(DOORs_Module_Report_path)

for doors_file in doors_dir_list:
    if(doors_file.endswith(".xls")):
        doors_file_path = DOORs_Module_Report_path+"\\"+doors_file
        out_path = DOORs_Module_Report_path+"\\"+doors_file.replace(".xls",".xlsx")
        convert_xlx_to_xlsx(doors_file_path,out_path)
        print(doors_file)
        



