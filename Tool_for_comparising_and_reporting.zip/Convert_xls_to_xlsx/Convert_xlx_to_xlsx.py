import pandas as pd
import os
import configparser



def convert_xlx_to_xlsx(file_path,out_path):
    data = pd.read_html(file_path)
    print(len(data))
    data[0].to_excel(out_path,index=False,header=False)

parser = configparser.SafeConfigParser()
parser.read('config.ini')
fol_path = parser.get('file_path','project_fol_path')

fol_contents = os.listdir(fol_path)

for proj in fol_contents:
    DOORs_Module_Report_path = fol_path+"\\"+proj+"\\"+"DOORs Module Report"
    doors_dir_list = os.listdir(DOORs_Module_Report_path)

    for doors_file in doors_dir_list:
        if(doors_file.endswith(".xls")):
            doors_file_path = DOORs_Module_Report_path+"\\"+doors_file
            out_path = DOORs_Module_Report_path+"\\"+doors_file.replace(".xls",".xlsx")
            convert_xlx_to_xlsx(doors_file_path,out_path)
            print(doors_file)
