#===============================================================================
#     CREATE A PROJECT FOLDER FOR EACH DOORS PROJECT
#===============================================================================

import os
from openpyxl import load_workbook
import configparser

parser = configparser.ConfigParser()
parser.read('config.ini')
fol_path_for_projects = parser.get('file_path', 'project_fol_path')


def Create_a_Sub_Folders(new_proj_fol):

    list_of_fol_to_create = ["Codebeamer Tracker Report","DOORs Module Report","Module Descriptor Report","Ref Creator Report","TMRT View Report"]

    for cre_fol in list_of_fol_to_create:
        sub_fol = new_proj_fol+"\\"+cre_fol
        try:
            os.mkdir(sub_fol)
        except:
            print("Sub-Folder Already Exists")


def create_Project_folder(filepath):
    #===========================================================================
    # CREATE A PROJECT FOLDER FOR EACH DOORS PROJECT
    #===========================================================================

    Doors_project_name_list = []
    wb=load_workbook(filepath)
    # select demo.xlsx
    sheet=wb.active
    # get max row count
    max_row=sheet.max_row
    # get max column count
    max_column=sheet.max_column
    # iterate over all cells
    # iterate over all rows
    for i in range(1,max_row+1):
        cell_obj=sheet.cell(row=i,column=1)
        doors_proj_name = cell_obj.value
        Doors_project_name_list.append(doors_proj_name)
        path = fol_path_for_projects+"\\"+doors_proj_name
        print(doors_proj_name)
        try:
            os.mkdir(path)
        except:
            print("Folder Already Exists")

        Create_a_Sub_Folders(path)
    return Doors_project_name_list

if __name__ == "__main__":
        filepath = parser.get('file_path', 'doors_project_list_file_path')
        create_Project_folder(filepath)
        print("##################### Completed #####################")