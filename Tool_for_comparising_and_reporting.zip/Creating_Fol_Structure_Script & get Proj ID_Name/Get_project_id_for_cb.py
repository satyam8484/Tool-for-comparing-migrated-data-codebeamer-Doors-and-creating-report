
#===============================================================================
# FOR WRITTING DATA OF CB PROJECT ID & NAME TO EXCEL FILE
#===============================================================================

import json
import requests
from requests.auth import HTTPBasicAuth
import configparser
import os
from openpyxl import Workbook

parser = configparser.ConfigParser()
parser.read('config.ini')
usr_name = parser.get('Tracker_view_Configuration', 'user_name')
pwd = parser.get('Tracker_view_Configuration', 'password')
fol_path_for_projects = parser.get('file_path', 'project_fol_path')

def Create_a_Sub_Folders(new_proj_fol):

    list_of_fol_to_create = ["Codebeamer Tracker Report","DOORs Module Report","Module Descriptor Report","Ref Creator Report","TMRT View Report"]

    for cre_fol in list_of_fol_to_create:
        sub_fol = new_proj_fol+"\\"+cre_fol
        try:
            os.mkdir(sub_fol)
        except:
            print("Sub-Folder Already Exists")


def write_xls(filepath, dictionary):
    wb=Workbook()
    sheet = wb.active

    headers = [x for x in dictionary[0]]

    for index, value in enumerate(headers):
        sheet.cell(row=1, column=index+1).value = value

    for i, x in enumerate(dictionary):
        for idx,value in enumerate(x.values()):
            sheet.cell(row=i+2, column=idx+1).value = value
            if(idx == 1):
                value = value.replace("/","_")
                proj_fol_path = fol_path_for_projects+"\\"+value
                try:
                    os.mkdir(proj_fol_path)
                except:
                    print(proj_fol_path)

                Create_a_Sub_Folders(proj_fol_path)

    wb.save(filepath)


def get_project_id():
    filepath = "Project_id.xlsx"
    URL = "http://bee.brose.net/cb/api/v3/projects"
    response = requests.get(URL,auth=HTTPBasicAuth(usr_name,pwd))
    Project_info = response.json()
    write_xls(filepath, Project_info)
    print("Complete")

if __name__ == '__main__':
    get_project_id()